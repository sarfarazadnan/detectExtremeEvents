% Detect Joint Extreme Events 
%E.Perugini, University of Strathclyde, Glasgow (UK)
%update: Feb2024

clear
close all

%% input
[file,path] = uigetfile('*.csv','Select input file');
inf = readcell(strcat(path,file), 'NumHeaderLines',1);
inf1 = cell2table(inf,'VariableNames',{'INPUT','value','unit'});
try
th_1=inf{1,2};
th_2=inf{2,2};
dtr=inf{3,2};
ev_1=inf{4,2};
ev_2=inf{5,2};
pot_1=inf{6,2};
pot_2=inf{7,2};
Wd=inf{8,2};
w_type=inf{9,2};
end
if ~exist('w_type'); w_type='m'; end

%% Load and overlap data
[file1,path1] = uigetfile('*.csv','Select Driver 1');
dr1_raw = readtable(strcat(path1,file1), 'NumHeaderLines',2);
dr1_raw.Properties.VariableNames = {'Time', 'Driver1'}; % names of columns
dr1_raw=table2timetable(dr1_raw);
unit1=char(readcell(strcat(path1,file1),'Range','B2:B2'));
quantity1=char(readcell(strcat(path1,file1),'Range','B1:B1'));

[file2,path2] = uigetfile('*.csv','Select Driver 2');
dr2_raw = readtable(strcat(path2,file2), 'NumHeaderLines',2);
dr2_raw.Properties.VariableNames = {'Time', 'Driver2'}; % names of columns
dr2_raw=table2timetable(dr2_raw);
unit2=char(readcell(strcat(path2,file2),'Range','B2:B2'));
quantity2=char(readcell(strcat(path2,file2),'Range','B1:B1'));

%known events
try
[file3,path3] = uigetfile('*.csv','Select known events');
% dr3_raw = readtable(strcat(path3,file3), 'NumHeaderLines',2);
% dr3_raw.Properties.VariableNames = {'Time', 'Driver3'}; % names of columns
% dr3_raw=table2timetable(dr3_raw);
dr3_raw_val = readcell(strcat(path3,file3),'Range','B:B','NumHeaderLines',2);
dr3_raw_t = readtable(strcat(path3,file3), 'NumHeaderLines',2,'Range','A:A');
dr3_raw=table(dr3_raw_t.Var1,dr3_raw_val);
dr3_raw.Properties.VariableNames = {'Time', 'Driver3'}; % names of columns
dr3_raw=table2timetable(dr3_raw);
unit3=char(readcell(strcat(path3,file3),'Range','B2:B2'));
quantity3=char(readcell(strcat(path3,file3),'Range','B1:B1'));
% str=num2str(dr3_raw.Driver3);
str=dr3_raw.Driver3;
for s=1:length(dr3_raw.Driver3)
    if  isnumeric(str{s,:})
        STR(s)=cellstr([num2str(str{s,:}),' ',unit3]);
    else
        STR(s)=cellstr([str{3,:},' ', unit3]);
    end
end
end

in_1=dr1_raw.Time(1);
fin_1=dr1_raw.Time(end);
in_2=dr2_raw.Time(1);
fin_2=dr2_raw.Time(end);

in=max(in_2,in_1);
fin=min(fin_2,fin_1);
id_1=find(dr1_raw.Time>=in & dr1_raw.Time<=fin);
id_2=find(dr2_raw.Time>=in & dr2_raw.Time<=fin);

dr1=dr1_raw(id_1,:);
dr2=dr2_raw(id_2,:);

figure(1)
subplot(2,1,1)
    hold on
    plot(dr1_raw.Time,dr1_raw.Driver1,"Color",[0.5 0.5 0.5])
    plot(dr1.Time,dr1.Driver1,'b')
    xlim([min(in_2,in_1) max(fin_2,fin_1)])
    xlabel('Time')
    ylabel([quantity1,' (',unit1,')'])
    title('Driver 1')
    grid on
subplot(2,1,2)
    hold on
    plot(dr2_raw.Time,dr2_raw.Driver2,"Color",[0.5 0.5 0.5])
    plot(dr2.Time,dr2.Driver2,'b')
    xlim([min(in_2,in_1) max(fin_2,fin_1)])
    title('Driver 2')
    xlabel('Time')
    ylabel([quantity2,' (',unit2,')'])
    grid on



%% Uniform time series
if ischar(dtr)
    dt=dtr;
    Max_1 = retime(dr1,dt,'max');
else
    dtp=hours(dtr);
    dt=[num2str(dtr),'-hours'];
    Max_1 = retime(dr1,'regular','max','TimeStep',dtp);
end

if ischar(dtr)
    dt=dtr;
    Max_2 = retime(dr2,dt,'max');
else
    dtp=hours(dtr);
    dt=[num2str(dtr),'-hours'];
    Max_2 = retime(dr2,'regular','max','TimeStep',dtp);
end

[~,i1,i2]=intersect(Max_1.Time,Max_2.Time);
Max_1=Max_1(i1,:);
Max_2=Max_2(i2,:);

%% Driver1 Extreme events
[TF_1,~,U_1,~] = isoutlier(Max_1.Driver1,'percentiles',[0 th_1]);

if pot_1==1
    [~, id_p_1]=findpeaks(Max_1.Driver1,'MinPeakHeight',U_1,'MinPeakDistance',ev_1);
    extDriver1=timetable(Max_1.Time(id_p_1),Max_1.Driver1(id_p_1),'VariableNames',{'Driver1'});
else
    extDriver1=Max_1(TF_1,:);
end

figure(2)
hold on
plot(dr1.Time,dr1.Driver1, "Color",[0.5 0.5 0.5],'MarkerSize',0.5)
plot(Max_1.Time,Max_1.Driver1,'.b','MarkerSize',0.5)
plot(Max_1.Time(TF_1),Max_1.Driver1(TF_1),".r",'MarkerSize',0.8)
yline([U_1],'k-.',[num2str(th_1),'th percentile'],'FontWeight','bold','LineWidth',1)
if pot_1==1
    plot(Max_1.Time(id_p_1),Max_1.Driver1(id_p_1),'*k','MarkerSize',2)
    legend('Raw Data',[dt, ' Max Data'],'Over threshold Data','Threshold','Peak Over Threshold Data',Location='best')
else
    legend('Raw Data',[dt, ' Max Data'],'Over threshold Data','Threshold',Location='best')
end
xlabel('Time')
ylabel([dt, ' max ', quantity1,' (',unit1,')'])
grid on
title(quantity1)
if exist("dr3_raw")
    xline(dr3_raw.Time,'g',STR,'linewidth',1)
    if pot_1==1
        legend('Raw Data',[dt, ' Max Data'],'Over threshold Data','Threshold','Peak Over Threshold Data',[quantity3],Location='best')
    else
        legend('Raw Data',[dt, ' Max Data'],'Over threshold Data','Threshold',[quantity3],Location='best')
    end
end

%% Driver2 Extreme events
[TF_2,~,U_2,~] = isoutlier(Max_2.Driver2,'percentiles',[0 th_2]);

if pot_2==1
    [~, id_p_2]=findpeaks(Max_2.Driver2,'MinPeakHeight',U_2,'MinPeakDistance',ev_2);
    extDriver2=timetable(Max_2.Time(id_p_2),Max_2.Driver2(id_p_2),'VariableNames',{'Driver2'});
else
    extDriver2=Max_2(TF_2,:);
end

figure(3)
hold on
plot(dr2.Time,dr2.Driver2, "Color",[0.5 0.5 0.5],'MarkerSize',0.5)
plot(Max_2.Time,Max_2.Driver2,'.b','MarkerSize',0.8)
plot(Max_2.Time(TF_2),Max_2.Driver2(TF_2),".r",'MarkerSize',0.8)
yline([U_2],'k-.',[num2str(th_2),'th percentile'],'FontWeight','bold','LineWidth',1)
if pot_2==1
    plot(Max_2.Time(id_p_2),Max_2.Driver2(id_p_2),'*k','MarkerSize',2)
    legend('Raw Data',[dt, ' Max Data'],'Over threshold Data','Threshold','Peak Over Threshold Data',Location='best')
else
    legend('Raw Data',[dt, ' Max Data'],'Over threshold Data','Threshold',Location='best')
end
xlabel('Time')
ylabel([dt, ' max ', quantity2,' (',unit2,')'])
grid on
title(quantity2)
if exist("dr3_raw")
    xline(dr3_raw.Time,'g',STR,'linewidth',1)
    if pot_2==1
        legend('Raw Data',[dt, ' Max Data'],'Over threshold Data','Threshold','Peak Over Threshold Data',[quantity3], Location='best')
    else
        legend('Raw Data',[dt, ' Max Data'],'Over threshold Data','Threshold',[quantity3],Location='best')
    end
end


%% CO-OCCURRENT EVENTS

switch w_type
    case 'm'
        wd=max(min(diff(extDriver1.Time)),min(diff(extDriver2.Time)));
        if Wd>days(wd), Wd=days(wd); disp(['Adjusted Search Window: ',num2str(Wd),' days']); end

        % Look for the simultaneous events in a search window centred around the
        % events of the extreme timeseries which has the larger temporal distance,
        % if equal select the first
        if min(diff(extDriver1.Time))>=min(diff(extDriver2.Time))
            Ea.Time=extDriver1.Time; Ea.Value=extDriver1.Driver1; %seacrh window around Driver 1
            Eb.Time=extDriver2.Time; Eb.Value=extDriver2.Driver2;
            [Time, Driver1, Driver2,Time2]=findJointEvents(Ea,Eb,Wd,w_type);
            Time=Time'; Driver1=Driver1'; Driver2=Driver2';
            ExtEvents=table(Time,Driver1,Driver2);
            Time1=Time;
        else
            Ea.Time=extDriver2.Time; Ea.Value=extDriver2.Driver2; %seacrh window around Driver 2
            Eb.Time=extDriver1.Time; Eb.Value=extDriver1.Driver1;
            [Time, Driver2, Driver1, Time1]=findJointEvents(Ea,Eb,Wd,w_type);
            Time=Time'; Driver1=Driver1'; Driver2=Driver2';
            ExtEvents=table(Time,Driver1,Driver2);
            Time2=Time;
        end

    case 't'
        list = {quantity1; quantity2};
        prompt = {'Which is the triggering driver?'};
        [indx,~] = listdlg('PromptString',prompt,...
            'SelectionMode','single','ListString',list);

        % Look for the simultaneous events in a search window forward-shifted from the
        % events of the triggering extreme timeseries. 
        if indx==1 %Driver1 is the triggering driver
            wd=min(diff(extDriver1.Time));
            if Wd>days(wd), Wd=days(wd); disp(['Adjusted Search Window: ',num2str(Wd),' days']); end
            
            Ea.Time=extDriver1.Time; Ea.Value=extDriver1.Driver1; %seacrh window around Driver 1
            Eb.Time=extDriver2.Time; Eb.Value=extDriver2.Driver2;
            [Time, Driver1, Driver2,Time2]=findJointEvents(Ea,Eb,Wd,w_type);
            Time=Time'; Driver1=Driver1'; Driver2=Driver2';
            ExtEvents=table(Time,Driver1,Driver2);
            Time1=Time;

        elseif indx==2 %Driver2 is the triggering driver
            wd=min(diff(extDriver2.Time));
            if Wd>days(wd), Wd=days(wd); disp(['Adjusted Search Window: ',num2str(Wd),' days']); end

            Ea.Time=extDriver2.Time; Ea.Value=extDriver2.Driver2; %seacrh window around Driver 2
            Eb.Time=extDriver1.Time; Eb.Value=extDriver1.Driver1;
            [Time, Driver2, Driver1, Time1]=findJointEvents(Ea,Eb,Wd,w_type);
            Time=Time'; Driver1=Driver1'; Driver2=Driver2';
            ExtEvents=table(Time,Driver1,Driver2);
            Time2=Time;
        end

end

% CORRELATION
X=ExtEvents.Driver2;
Y=ExtEvents.Driver1;
rho=corr(X,Y,'Type','Kendall');


figure(4);
plot(Max_1.Driver1,Max_2.Driver2,'.b')
hold on
plot(ExtEvents.Driver1,ExtEvents.Driver2,'.r','MarkerSize',10)
xlabel([dt, ' max ', quantity1,' (',unit1,')'])
ylabel([dt, ' max ', quantity2,' (',unit2,')'])
grid on
legend([dt, ' Data'],'Selected Extremes',Location='best')
title([quantity1,': ', num2str(th_1), 'th  --  ',quantity2,': ', num2str(th_2),'th'])
subtitle({['\tau = ', num2str(rho)],[num2str(length(Time)),' extreme events'],...
    [quantity1, ' threshold = ',num2str(U_1),' ', unit1,' -- ',quantity2, ' threshold = ',num2str(U_2),' ',unit2]})


%% diagnostic figure
figure(5); clf;
set(figure(5), 'Position', [20 100 1500 600]);
sub1=subplot(6,1,[1:5]);
yyaxis right
    set(sub1,'Position',[0.06 0.24 0.88 0.6725])
    hold on
    plot(dr1.Time,dr1.Driver1, "Color",[0.8 0.8 0.96],'MarkerSize',0.5)
%     plot(Max_1.Time,Max_1.Driver1,'.b','MarkerSize',1)
    plot(extDriver1.Time,extDriver1.Driver1,"b.",'MarkerSize',2)
    plot(Time1,ExtEvents.Driver1,'c*','MarkerSize',4)
    xlim([max(in_2,in_1) min(fin_2,fin_1)])
    ylabel([quantity1,' (',unit1,')'])
    title('Diagnostic figure')
    if exist('dr3_raw')
    xline(dr3_raw.Time,'g',STR,'linewidth',1)
    end
yyaxis 'left'
    hold on
    plot(dr2.Time,dr2.Driver2, "Color",[0.92 0.82 0.82],'MarkerSize',0.5)
%     plot(Max_2.Time,Max_2.Driver2,'.r','MarkerSize',1)
    plot(extDriver2.Time,extDriver2.Driver2,"r.",'MarkerSize',2)
    plot(Time2,ExtEvents.Driver2,'*r','MarkerSize',4)
    xlim([max(in_2,in_1) min(fin_2,fin_1)])
    ylabel([quantity2,' (',unit2,')'])
    ax = gca;
sub1.YAxis(2).Color = 'b';
sub1.YAxis(1).Color = 'r';
set(sub1,'XTickLabel',[])
grid on
box on
if exist('dr3_raw')
    legend([' Raw Data ',quantity2], ['Extreme values ', quantity2],['Joint Extreme values ',quantity2],...
        [' Raw Data ',quantity1], ['Extreme values ', quantity1],['Joint Extreme values ',quantity1],[quantity3]); %legend(left,right)
else
    legend([' Raw Data ',quantity2], ['Extreme values ', quantity2],['Joint Extreme values ',quantity2],...
        [' Raw Data ',quantity1], ['Extreme values ', quantity1],['Joint Extreme values ',quantity1]); %legend(left,right)
end

sub2=subplot(6,1,6);
box on
set(sub2,'Position',[0.06 0.11 0.88 0.1026])
if isdatetime(Time1)
hold on
plot(Time1,0.5*ones(size(Time1)),'xc','MarkerSize',8)
plot(Time2,0.5*ones(size(Time2)),'or','MarkerSize',8)
if exist('dr3_raw')
xline(dr3_raw.Time,'g',STR,'linewidth',1)
end
grid on
set(sub2,'YTickLabel',[])
xlim([max(in_2,in_1) min(fin_2,fin_1)])
xlabel('Time')
if exist('dr3_raw')
legend(['Joint Extreme values',quantity1],['Joint Extreme values',quantity2],[quantity3])
else
legend(['Joint Extreme values',quantity1],['Joint Extreme values',quantity2])
end
end

%% seasonality

%seasonality Driver1
mm_1=month(extDriver1.Time);
figure(6)
set(gcf, 'Position', [220 260 1050 500]);
subplot(2,3,1)
histogram(mm_1)
xlim([0.5 12.5])
ylabel('n° of events')
xticks(1:12)
xticklabels({'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'})
title(['Extreme events ',quantity1, ' (',num2str(year(extDriver1.Time(1))),' - ', num2str(year(extDriver1.Time(end))),')'])

% seasonality Driver2
mm_2=month(extDriver2.Time);
subplot(2,3,4)
histogram(mm_2)
xlim([0.5 12.5])
ylabel('n° of events')
xticks(1:12)
xticklabels({'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'})
title(['Extreme events ',quantity2, ' (',num2str(year(extDriver2.Time(1))),' - ', num2str(year(extDriver2.Time(end))),')'])

% seasonality
mm=month(ExtEvents.Time);
subplot(2,3,[2,3,5,6])
histogram(mm)
xlim([0.5 12.5])
ylabel('n° of events')
xticks(1:12)
xticklabels({'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'})
title(['Joint Extreme events (',num2str(year(ExtEvents.Time(1))),' - ', num2str(year(ExtEvents.Time(end))),')'])




%% save
INFO=table(["Driver1";"Driver2";"Correlation coefficient";"n° of joint events";"Threshold Driver1";"Threshold Driver 2";"Search Window"],...
    [string(quantity1); string(quantity2); string(rho); string(length(ExtEvents.Time)); string(U_1); string(U_2); string(Wd)],...
    [unit1;unit2;"-";"-";unit1;unit2;"days"],'VariableNames',{'info','value','unit'});
disp(INFO)

try
    pause(2)
[fileout,pathout] = uiputfile('*.xlsx');
writetable(ExtEvents,strcat(pathout,fileout),'sheet','data')
writetable(INFO,strcat(pathout,fileout),'sheet','info')
writetable(inf1,strcat(pathout,fileout),'sheet','input')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% functions

function [Time, DriverA, DriverB,TimeB]=findJointEvents(Ea,Eb,Wd,w_type)
%search window around Ea

% identified the Eb values around each Ea event
switch w_type
    case 'm'
        for ii=1:length(Ea.Time)
            ind=find(isbetween(Eb.Time,Ea.Time(ii)-days((Wd-1)/2),Ea.Time(ii)+days((Wd-1)/2)));
            Eevents{ii}.Time=Ea.Time(ii);
            Eevents{ii}.Ea=Ea.Value(ii);
            Eevents{ii}.Eb=Eb.Value(ind);
            Eevents{ii}.TimeB=Eb.Time(ind);
            clear ind
        end
    case 't'
        for ii=1:length(Ea.Time)
            ind=find(isbetween(Eb.Time,Ea.Time(ii),Ea.Time(ii)+days(Wd)-1));
            Eevents{ii}.Time=Ea.Time(ii);
            Eevents{ii}.Ea=Ea.Value(ii);
            Eevents{ii}.Eb=Eb.Value(ind);
            Eevents{ii}.TimeB=Eb.Time(ind);
            clear ind
        end
end


% find the max Eb of each event and ignore Ea when it is no concomitant with Eb
jj=1;
for kk=1:length(Eevents)
    if ~isempty(Eevents{kk}.Eb)
        jEevents{jj}.Time=Eevents{kk}.Time;
        jEevents{jj}.Ea=Eevents{kk}.Ea;
        jEevents{jj}.Eb=max(Eevents{kk}.Eb);
        id_c=find(Eevents{kk}.Eb==max(Eevents{kk}.Eb));
        if length(id_c)>1; id_c=id_c(1); end
        jEevents{jj}.TimeB=Eevents{kk}.TimeB(id_c);
        jj=jj+1;
    end
end

%reshape
if exist('jEevents', 'var')
    for jj=1:length(jEevents)
    Time(jj)=jEevents{jj}.Time;
    DriverA(jj)=jEevents{jj}.Ea;
    DriverB(jj)=jEevents{jj}.Eb;
    TimeB(jj)=jEevents{jj}.TimeB;
    end
else
    Time=nan;
    DriverA=nan;
    DriverB=nan;
    TimeB=nan;
end
end

